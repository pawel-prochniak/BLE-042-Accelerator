/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <common.h>

int capsenseNotify;
int bleConnected = 0;

CYBLE_CONN_HANDLE_T connectionHandle;

void debug(char msg[])
{
    UART_UartPutString(msg);
    UART_UartPutString("\r\n");
}


void Stack_Handler( uint32 eventCode, void *eventParam )
{
    CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReq;
    
    switch ( eventCode )
    {
        //** GAP **
        case CYBLE_EVT_STACK_ON:
            CyBle_GappStartAdvertisement( CYBLE_ADVERTISING_FAST );
            AdvLED_Write(LED_ON);
            break;
        case CYBLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
            if(CYBLE_STATE_DISCONNECTED == CyBle_GetState())
                AdvLED_Write(LED_ON);
            break;
        
        case CYBLE_EVT_GAP_DEVICE_CONNECTED:
            debug("Connected to device");
            bleConnected = 0;
            AdvLED_Write(LED_OFF);
            ConnectedLED_Write(LED_ON);
            break;
            
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
            debug("Disconnected from device");
            ConnectedLED_Write(LED_OFF);
            AdvLED_Write(LED_ON);
            CyBle_GappStartAdvertisement( CYBLE_ADVERTISING_FAST );
            break;
       
            
        //** GATT **
        case CYBLE_EVT_GATT_CONNECT_IND:
            connectionHandle = *(CYBLE_CONN_HANDLE_T *) eventParam;
            bleConnected = 1;
            break;
            
        case CYBLE_EVT_GATTS_WRITE_REQ:
            wrReq = (CYBLE_GATTS_WRITE_REQ_PARAM_T *) eventParam;
            if ( wrReq->handleValPair.attrHandle == CYBLE_NOISE_NOISE_CHAR_NOISECCCD_DESC_HANDLE )
            {
                CyBle_GattsWriteAttributeValue( &wrReq->handleValPair, 0, &connectionHandle, CYBLE_GATT_DB_LOCALLY_INITIATED);
                capsenseNotify = wrReq->handleValPair.value.val[0];
                
                debug("Setting notify val");
                UART_UartPutChar(capsenseNotify);
            }
            CyBle_GattsWriteRsp( connectionHandle );
            break;
           
        default:
            break;
           
            
    }
}

int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    BlueLED_Write(LED_OFF);
    AdvLED_Write(LED_OFF);
    ConnectedLED_Write(LED_OFF);

    CyBle_Start(Stack_Handler);
    
    UART_Start();
    
    PRS_Start();

    for(;;)
    {
        /* Process all the generated events. */
        CyBle_ProcessEvents();
        
        if (bleConnected) 
        {
            uint8 prsVal = (uint8) PRS_Read();

           // debug("Read value of %d", prsVal);
            
            CYBLE_GATTS_HANDLE_VALUE_NTF_T noiseHandle;
                // capsenseHandle.attrHandle = CYBLE_CAPSENSE_SLIDER_CHAR_HANDLE;
            noiseHandle.attrHandle = CYBLE_NOISE_NOISE_CHAR_CHAR_HANDLE;
            noiseHandle.value.len = sizeof(prsVal);
            noiseHandle.value.val = &prsVal;           
                
            CyBle_GattsWriteAttributeValue( &noiseHandle, 0u, &connectionHandle, 0 );
                
            if (capsenseNotify)
            {
                debug("Notifing\n");
                CyBle_GattsNotification( connectionHandle, &noiseHandle );
            } 
                
                    
        }
    }
}

/* [] END OF FILE */
